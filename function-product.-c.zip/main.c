/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int multiply(int a,int b);
int main()
{
    int a,b,product;
    printf("enter any 2 nos.");
    scanf("%d%d",&a,&b);
    product=multiply(a,b);
    printf("the product of 2 nos. is %d",product);

    return 0;
}
int multiply(int a,int b){
    int product;
    product=a*b;
    return product;
}