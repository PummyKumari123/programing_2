/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int evenodd(int n);
int main()
{
    int n;
    printf("enter any no.");
    scanf("%d",&n);
    int result=evenodd(n);
    printf("the no. is %d",result);

    return 0;
}
int evenodd(int n){
int result;
if(n%2==0){
    n;even;}
    else{
        n;odd;}
return result;
}
