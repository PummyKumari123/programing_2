/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int sum=0,rem,n,original;

    printf("enter any no.");
    scanf("%d",&n);
    original=n;
    while(n!=0)
    {
        rem=n%10;
        sum=sum+rem*rem*rem;
        n=n/10;
    }
    if(sum==original)
    {
        printf("no. is armstrong");
    }
    else
    {
        printf("no. is not armstrong");
    }
    

    return 0;
}


