/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int i,j ,rows;
    printf("enter the no. of rows");
    scanf("%d",&rows);
    for(i=1;i<=rows;i++) {
        for(j=i;j>=1;j--){
            printf("%d",j%2);}
            printf("\n");}
    return 0;
}

