/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
   int i,j; 
   for(i=1;i<=5;i++){
       
       for(j=2;j<=2+i;j++)
{
    if(i%2!=0){
        printf("%d",i);}
        else{
            printf("%d",j);
            j=j+1;}
    }
    printf("\n");}
    return 0;
}


