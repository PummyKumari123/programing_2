/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int factorial(int num);
int main()
{
    int fact,num;
    printf("enter any no. which do u want factorial\t");
    scanf("%d",&num);
    fact=factorial(num);
    printf("the factorial is %d",fact);

    return 0;
}
int factorial (int num){
    int fact=1;
    int i=1;
    for(i=1;i<=num;i++){
        fact=fact*i; }
        return fact;
}
