/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int add(int a,int b);

int main()
{
    int a,b,c;
    printf("enter two no.");
    scanf("%d%d",&a,&b);
    c=add(a,b);
    
    printf("sum is %d",c);

    return 0;
}

int add(int a,int b){
    int sum ;
    sum=a+b;
    return sum;
}
