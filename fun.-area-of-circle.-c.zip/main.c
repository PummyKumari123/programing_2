/******************************************************************************
 * 
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
float areacircle (float radius);
float circumcircle(float radius);
int main()
{
    float radius,area,circum; 
    printf("enter radius");
    scanf("%f",&radius);
    area=areacircle(radius);
    circum=circumcircle(radius);
    printf("area of circle is %.3f\n",area);
printf("circumcircle is %.3f",circum);
    return 0;
}
float areacircle(float radius){

    float area;
    area=3.14*radius*radius;
    return area;}
    float circumcircle(float radius){
        float circum;
        circum=2*3.14*radius;
        
    return circum;
}


