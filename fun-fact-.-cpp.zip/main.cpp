/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int factorial (int num);
int main()
{
    int fact,num;
    cout<<"enter the no.\t";
    cin>>num;
    fact=factorial(num); 
    cout<<fact<<endl;
    return 0;
}
int factorial (int num){
    int fact=1;
    int i=1;
    
        for(i=1;i<=num;i++){
            fact=fact*i;}
            return fact;
}
        

