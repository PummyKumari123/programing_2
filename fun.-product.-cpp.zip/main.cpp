/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
int multiply(int a,int b);
using namespace std;

int main()
{
    int a,b,product;
    cout<<"enter any 2 no.";
    cin>>a,b;
    product=multiply(a,b);
    cout<<product<<endl;

    return 0;
}
int multiply(int a,int b){
    int product;
    product=a*b;
    return product;
}